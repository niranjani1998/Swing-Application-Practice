package niji;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Cursor;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class button {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final Display display=new Display();
        final Shell shell=new Shell(display);
        shell.setSize(450,500);
        shell.setLayout( new GridLayout());
        final Cursor[] cursor = new Cursor[1];
        Button button1=new Button(shell,SWT.PUSH);
        button1.setText("Start");
        Point size1=button1.computeSize(SWT.DEFAULT, SWT.DEFAULT);
        button1.setSize(size1);
        Button button2=new Button(shell,SWT.CALENDAR);
        button2.setText("Calendar");
        Point size2=button2.computeSize( SWT.DEFAULT, SWT.DEFAULT);
        button2.setSize(size2);
        Button button3=new Button(shell,SWT.ICON_SEARCH);
        button3.setText("Search");
        Point size3=button3.computeSize( 100, 100);
        button3.setSize(size3);
        Button button4=new Button(shell,SWT.COLOR_DARK_GREEN);
        button4.setText("Color");
        Point size4=button4.computeSize( 200,200);
        button4.setSize(size4);
        shell.open();
        
        while(!shell.isDisposed()) {
        	if(!display.readAndDispatch())
        		display.sleep();
        		
        }
        if (cursor[0] != null)
		      cursor[0].dispose();
        display.dispose();
        
	}

}
