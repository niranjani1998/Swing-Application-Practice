package Task2;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Shell;

public class file {
	 private static void Shell(Display display, Shell shell) {
		 String[] filterExtensions = { "*.txt"};

		 FileDialog fileDialog = new FileDialog(shell, SWT.OPEN);

		 fileDialog.setText("FileDialog Demo");

		 fileDialog.setFilterPath("C:\\Users\\user\\niji/");

		 fileDialog.setFilterExtensions(filterExtensions);

		// String selectedFile = fileDialog.open();
		  String selectedFile = fileDialog.open();
		  

		  System.out.println("User selected : " + selectedFile);
		  shell.dispose();
		 }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Display display = new Display();

		
		  Shell shell = new Shell(display);
		  shell.setSize(500, 500);
		  Shell(display, shell);

		 

		  while (!shell.isDisposed()) {
		   if (!display.readAndDispatch()) {
		    display.sleep();
		   }
		  }

		 
		  display.dispose();
	}

}
