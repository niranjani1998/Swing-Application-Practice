package niji;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Cursor;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class control {
	public static void main(String [] args) {
		 final Display display = new Display();
		    final Shell shell = new Shell(display);
		    shell.setSize(300, 400);
		   final Cursor[] cursor = new Cursor[1];
		    Button button = new Button(shell, SWT.PUSH);
		    button.setText("Change cursor");
		    Point size = button.computeSize(SWT.DEFAULT, SWT.DEFAULT);
		    button.setSize(size);

		    shell.open();
		    while (!shell.isDisposed()) {
		      if (!display.readAndDispatch())
		        display.sleep();
		    }
		   if (cursor[0] != null)
		      cursor[0].dispose();
		    display.dispose();
	}

}
