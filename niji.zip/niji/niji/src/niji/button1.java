package niji;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class button1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final Display display=new Display();
         final Shell shell=new Shell(display);
        shell.setSize(450,500);
        shell.setLayout( new GridLayout());
       // final Cursor[] cursor = new Cursor[1];
        Button button1=new Button(shell,SWT.PUSH);
        button1.setText("Start");
        button1.setSize(50,50);
        Button button2=new Button(shell,SWT.CALENDAR);
        button2.setText("Calendar");
        button2.setSize(50,50);
        Button button3=new Button(shell,SWT.ICON_SEARCH);
        button3.setText("Search");
        button3.setSize(50,50);
        Button button4=new Button(shell,SWT.COLOR_DARK_GREEN);
        button4.setText("Color");
        button4.setSize(50,50);
        shell.open();
        
        while(!shell.isDisposed()) {
        	if(!display.readAndDispatch())
        		display.sleep();
        		
        }
        display.dispose();
	}

}
