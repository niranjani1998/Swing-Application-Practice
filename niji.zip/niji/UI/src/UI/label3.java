package UI;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

public class label3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Display display = new Display();
		    Shell shell = new Shell();
		    shell.setLayout(new GridLayout(1, false));


		    
		    Label separator = new Label(shell, SWT.HORIZONTAL | SWT.SEPARATOR);
		    separator.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));


		    shell.open();
		    while (!shell.isDisposed()) {
		      if (!display.readAndDispatch()) {
		        display.sleep();
		      }
		    }
		    display.dispose();
	}

}
