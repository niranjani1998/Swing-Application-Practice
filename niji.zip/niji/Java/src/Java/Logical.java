package Java;

public class Logical {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int a=10,b=5,c=8;
        System.out.println((a>b)&&(c>b));
        System.out.println((a<b)||(c<b));
	}

}
