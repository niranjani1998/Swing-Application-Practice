package task;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class Default {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final Display display = new Display();
	    Shell shell = new Shell(display);

	    shell.setLayout(new RowLayout());
         //shell.setLayout( new FillLayout());
	    final String[] ratings = new String[] { "A", "B", "C","D" };
	    final Button[] radios = new Button[ratings.length];
	    for (int i = 0; i < ratings.length; i++) {
	      radios[i] = new Button(shell, SWT.RADIO);
	      radios[i].setText(ratings[i]);
	    }

	    Button cancelButton = new Button(shell, SWT.PUSH);
	    cancelButton.setText("Cancel");

	    Button rateButton = new Button(shell, SWT.PUSH);
	    rateButton.setText("OK");
	  
	 

	    shell.open();
	    while (!shell.isDisposed()) {
	      if (!display.readAndDispatch()) {
	        display.sleep();
	      }
	    }

	}

}
