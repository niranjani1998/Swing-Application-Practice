package Controlstatements;

public class Protected {

	protected void display() 
    { 
        System.out.println("Default variable"); 
    } 

}
