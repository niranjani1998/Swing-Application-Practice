package niji;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class PreferredSize {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	    final Display display = new Display();
	    Shell shell = new Shell(display);

	    shell.setLayout(new GridLayout());

	    Button button = new Button(shell, SWT.PUSH | SWT.LEFT);
	    button.setText("PrefferedSize");

	   // System.out.println("toControl: " + button.toControl(200, 400));

	    System.out.println("toDisplay: " + button.toDisplay(100, 200));
	    shell.open();
	    while (!shell.isDisposed()) {
	      if (!display.readAndDispatch()) {
	        display.sleep();
	      }
	    
	}

}
}
