package Controlstatements;

public class ForEach {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int [] number= {1,2,3,4};
       for(int i: number) {
    	   System.out.println(i);
       }
	}

}
