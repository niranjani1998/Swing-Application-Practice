package Task1;


	public class Dog extends absclass{

		   public void sound(){
			System.out.println("Woof");
		   }

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			absclass obj = new Dog();
			obj.sound();
		}

	}



