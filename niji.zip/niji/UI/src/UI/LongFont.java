package UI;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class LongFont {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Display display = new Display();
		    Shell shell = new Shell(display);

		    Text text = new Text(shell, SWT.MULTI|SWT.BORDER);
		    text.setBounds(10, 10, 150, 150);
		    Font initialFont = text.getFont();
		    FontData[] fontData = initialFont.getFontData();
		    for (int i = 0; i < fontData.length; i++) {
		      fontData[i].setHeight(24);
		    }
		    Font newFont = new Font(display, fontData);
		    text.setFont(newFont);
		    shell.open();
		    while (!shell.isDisposed()) {
		      if (!display.readAndDispatch())
		        display.sleep();
		    }
		    newFont.dispose();
		    display.dispose();
	}

}
