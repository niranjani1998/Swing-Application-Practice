package Controlstatements;

import java.util.Scanner;

public class For {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int i,n;
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the number");
        n=s.nextInt();
        for(i=1;i<=n;i++) {
        	System.out.println(i);
        }
        
	}

}
