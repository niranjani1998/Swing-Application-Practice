package Task2;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;

public class MsgBox {
	 public static void addWidgetsToShell(Display display, Shell shell) {
		  shell.open();
		  MessageBox messageBox = new MessageBox(shell, SWT.ICON_QUESTION | SWT.YES | SWT.NO | SWT.CANCEL);
		  messageBox.setMessage("Are you male?");
		  messageBox.setText("MessageBoxDemo");
		  int response = messageBox.open();

		  switch (response) {
		  case SWT.YES:
			  //shell.addListener(SWT.Selection, event -> doShowMessageBox());
			  shell.pack();
		   System.out.println("Good Morning Mr..");
		   break;
		  case SWT.NO:
		   System.out.println("Good Morning Ms");
		   break;
		  case SWT.CANCEL:
		   System.out.println("The user cancelled.");
		   break;
		  }
	 }

	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  Display display = new Display();

		
		  Shell shell = new Shell(display);
		  shell.setSize(500, 500);
		  addWidgetsToShell(display, shell);

		
		  while (!shell.isDisposed()) {
		   if (!display.readAndDispatch()) {
		    display.sleep();
		   }
		  }

		  /* Dispose the display */
		  display.dispose();
	}

}
