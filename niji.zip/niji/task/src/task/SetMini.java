package task;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class SetMini {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Display display=new Display();
       Shell shell=new Shell(display);
       shell.setMinimized(true);
       Color color=display.getSystemColor(SWT.COLOR_CYAN);
       
       shell.setBackground(color);
       shell.open();
       while(!shell.isDisposed()) {
    	   if(!display.readAndDispatch())
    		   display.sleep();
    	   
       }
       display.dispose();
	}

}
