package niji;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class boundsText {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		   Display display = new Display();
		    Shell shell = new Shell(display);
		    shell.setLayout(new GridLayout());
		    shell.setBounds(20, 20, 400, 400);

		    Button button1 = new Button(shell, SWT.PUSH);
		    button1.setText("Button1");
		    button1.setBounds(10, 10, 180, 100);
		    Button button2 = new Button(shell, SWT.PUSH);
		    button2.setText("Button2");
		    button2.setBounds(10, 30, 180, 100);

		    shell.open();
		    while (!shell.isDisposed()) {
		      if (!display.readAndDispatch())
		        display.sleep();
		    }
		    display.dispose();
	}

}
