package Java;

public class Arithmetic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         int a=5,b=6;
         System.out.println(a+b);
         System.out.println(a-b);
         System.out.println(a*b);
         System.out.println(a/b);
         System.out.println(a%b);
         
	}

}
