package Java;

public class Relational {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          int a=5,b=6;
          if(a>b) {
        	  System.out.println("greater"+a);
          }
          else {
        	  System.out.println("greater"+b);
          }
	}

}
