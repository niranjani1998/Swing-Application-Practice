package Java;

public class data {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int i=5;
        float f1=5.5f;
        char c='N';
        double dd=5.000d;
        byte by=100;
        short sh=5000;
        long lo=15000000L;
        System.out.println(i);
        System.out.println(f1);
        System.out.println(c);
        System.out.println(dd);
        System.out.println(by);
        System.out.println(sh);
        System.out.println(lo);
        
        
        
	}

}
