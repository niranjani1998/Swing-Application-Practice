package Task1;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Link;
import org.eclipse.swt.widgets.Shell;

public class link {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		   Display display = new Display();
		    Shell shell = new Shell(display);
		    Link link = new Link(shell, SWT.BORDER);
		    link.setText("This a very simple <A href=\"https://www.java2s.com\">link</A> widget.");
		    link.setSize(140, 140);
		    shell.pack ();
		    shell.open();
		    while (!shell.isDisposed()) {
		      if (!display.readAndDispatch())
		        display.sleep();
		    }
		    display.dispose();
	}

}
