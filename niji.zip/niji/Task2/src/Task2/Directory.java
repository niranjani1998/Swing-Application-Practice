package Task2;

import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class Directory {
	 private static void addWidgetsToShell(Display display, Shell shell) {
	 DirectoryDialog directoryDialog = new DirectoryDialog(shell);
	  directoryDialog.setText("DirectoryDialog Demo");
	  directoryDialog.setFilterPath("C:\\Users\\user\\niji");
	  String selectedDirectory = directoryDialog.open(); 
	  
	  System.out.println("User selected : " + selectedDirectory);
	  shell.dispose();
	 }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  Display display = new Display();

		  /*
		   * Define Shell, it represent a window, You can add more than one shell
		   * to Display
		   */
		  Shell shell = new Shell(display);
		  shell.setSize(500, 500);
		  addWidgetsToShell(display, shell);

		  /*
		   * Run the event dispatching loop until an exit condition occurs, which
		   * is typically when the main shell window is closed by the user.
		   */

		  while (!shell.isDisposed()) {
		   if (!display.readAndDispatch()) {
		    display.sleep();
		   }
		  }

		  /* Dispose the display */
		  display.dispose();

	}

}
