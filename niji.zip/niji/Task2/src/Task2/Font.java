package Task2;

import java.util.Objects;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FontDialog;
import org.eclipse.swt.widgets.Shell;

public class Font {
	 private static void addWidgetsToShell(Display display, Shell shell) {
		  FontData defaultFontData = new FontData("Courier", 12, SWT.ITALIC);
		  FontData[] fontList = { defaultFontData };
		  FontDialog fontDialog = new FontDialog(shell, SWT.NONE);
		  fontDialog.setText("FontDialog Demo");
		  fontDialog.setRGB(new RGB(0, 0, 255));
		  fontDialog.setFontList(fontList);
		  FontData fontData = fontDialog.open();

		  if (!Objects.isNull(fontData)) {
		   System.out.println("Font Name Selected:" + fontData.getName());
		   System.out.println("Font Height Selected:" + fontData.getHeight());
		   System.out.println("Font Style Selected:" + fontData.getStyle());
		   System.out.println("Font Colour Selected:" + fontDialog.getRGB());
		  }
		  shell.dispose();
		 }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Display display = new Display();

		  /*
		   * Define Shell, it represent a window, You can add more than one shell
		   * to Display
		   */
		  Shell shell = new Shell(display);
		  shell.setSize(500, 500);
		  addWidgetsToShell(display, shell);

		  /*
		   * Run the event dispatching loop until an exit condition occurs, which
		   * is typically when the main shell window is closed by the user.
		   */

		  while (!shell.isDisposed()) {
		   if (!display.readAndDispatch()) {
		    display.sleep();
		   }
		  }

		  /* Dispose the display */
		  display.dispose();

	}

}
