package Controlstatements;

public class While {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int i = 0;
		 int n=5,sum=0;
		    while (i < n) {
		    	sum=sum+i;
		    
		      i++;
		    } 
		     System.out.println(sum);
	}

}
