package Controlstatements;

import java.util.Scanner;

public class IfLadder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          int internal,external;
          Scanner sc=new Scanner(System.in);
          System.out.println("Enter the marks");
          internal=sc.nextInt();
          external=sc.nextInt();
          if(internal>25) {
        	  if(external>50) {
        		  System.out.println("Five marks extra");
        	  }
        	  else {
        		  System.out.println("Pass");
        	  }
          }
          else {
        	  System.out.println("Fail");
          }
	}

}
