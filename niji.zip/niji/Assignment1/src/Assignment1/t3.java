package Assignment1;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

public class t3 {
	  private Shell shell;
	    private Label label;

	    public t3(Display display) {

	        initUI(display);
	    }

	    private void initUI(Display display) {
	        
	        shell = new Shell(display, SWT.SHELL_TRIM | SWT.CENTER);

	        RowLayout layout = new RowLayout();
	        layout.marginHeight = 50;
	        layout.marginWidth = 50;
	        shell.setLayout(layout);

	        label = new Label(shell, SWT.NONE);
	        String homeDir = System.getProperty("user.home"); 
	        label.setText(homeDir);
	        label.pack();

	        shell.addListener(SWT.MouseDown, event -> onMouseDown());

	        shell.setText("FileDialog");
	        shell.pack();
	        shell.open();

	        while (!shell.isDisposed()) {
	          if (!display.readAndDispatch()) {
	            display.sleep();
	          }
	        }
	    }
	    
	    private void onMouseDown() {

	        FileDialog dialog = new FileDialog(shell, SWT.OPEN);

	        String[] filterNames = new String[] 
	            {"Java sources", "All Files (event2.txt)"};

	        String[] filterExtensions = new String[] 
	            {"*.java", "event2.txt"};

	        dialog.setFilterNames(filterNames);
	        dialog.setFilterExtensions(filterExtensions);

	        String path = dialog.open();
	        
	        if (path != null) {
	            
	            label.setText(path);
	            label.pack();
	            shell.pack();
	        }        
	    }


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Display display = new Display();
        t3 ex = new t3 (display);
        display.dispose();
	}

}
