package hello;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

public class hello {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         Display display= new Display();
         Shell shell= new Shell(display);
         Label label = new Label(shell,SWT.CENTER);
         label.setText("hello");
         label.setBounds(shell.getClientArea());
         shell.open();
         while(!shell.isDisposed()) {
        	 if(!display.readAndDispatch())
        		 display.sleep();
         }
         display.dispose();
	}

}
