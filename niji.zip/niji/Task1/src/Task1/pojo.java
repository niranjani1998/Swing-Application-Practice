package Task1;

class pojo {
	private int value=365;
	  public int getValue() {
	      return value;
	   }
	   public void setValue(int value) {
	      this.value = value;
	   }
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 pojo p = new pojo();
	      System.out.println(p.getValue());
	   }
	}


	
