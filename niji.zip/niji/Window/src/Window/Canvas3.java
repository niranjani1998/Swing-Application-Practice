package Window;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class Canvas3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Display display = new Display();
		    Shell shell = new Shell(display);
		    shell.setText("Canvas Example");
		    shell.setLayout(new FillLayout());

		    Canvas canvas = new Canvas(shell, SWT.NONE);

		    Button button = new Button(canvas, SWT.PUSH);
		    button.setBounds(10, 10, 300, 40);
		    button.setText("You can place widgets on a canvas");

		    canvas.addPaintListener(new PaintListener() {
		      public void paintControl(PaintEvent e) {
		        Rectangle rect = ((Canvas) e.widget).getBounds();
		        e.gc.setForeground(e.display.getSystemColor(SWT.COLOR_RED));
		        e.gc.drawFocus(5, 5, rect.width - 10, rect.height - 10);
		        e.gc.drawText("You can draw text directly on a canvas", 60, 60);
		      }
		    });

		    shell.open();
		    while (!shell.isDisposed()) {
		      if (!display.readAndDispatch()) {
		        display.sleep();
		      }
		    }
		    display.dispose();
	}

}
