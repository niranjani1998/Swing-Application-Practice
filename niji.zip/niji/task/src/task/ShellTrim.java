package task;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class ShellTrim {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Display display=new Display();
		Shell shell=new Shell(display);
		Image image=new Image(display,"C:\\Users\\user\\Pictures\\New folder\\IMG-20190930-WA0010.jpg");
        shell.setFullScreen(true);
        shell=new Shell(SWT.SHELL_TRIM);
        shell.setBackgroundImage(image);
        shell.open();
        while(!shell.isDisposed()) {
        	if(!display.readAndDispatch())
        		display.sleep();
        }
        display.dispose();
	}

}
