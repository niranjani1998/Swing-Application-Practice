package UI;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Layout;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
 
public class table {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Display display = new Display();
		    Shell shell = new Shell(display);
		    shell.setLayout( new GridLayout());
		    Button button1=new Button(shell,SWT.PUSH);
		    Button button2=new Button(shell,SWT.PUSH);
		    Button button3=new Button(shell,SWT.PUSH);
		    Button button4=new Button(shell,SWT.PUSH);
		    button1.setText("Import data");
		    button2.setText("Export data");
		    button3.setText("Total");
		    button4.setText("Sum of Parts Cost To");
		    Table table = new Table(shell, SWT.MULTI | SWT.BORDER | SWT.FULL_SELECTION);
		    table.setLinesVisible(true);
		    table.setHeaderVisible(true);

		    String[] titles = { "s.no", "PartName", "Materials", "Cost To Produce"};
		    for (int i = 0; i < titles.length; i++) {
		      TableColumn column = new TableColumn(table, SWT.NONE);
		      column.setText(titles[i]);
		    }
		    for (int i = 0; i < 10; i++) {
		        TableItem item = new TableItem(table, SWT.NONE);
		       
		        item.setText(2, "material");
		        item.setText(3, "Cost");
		       
		      }


		    for (int i=0; i<titles.length; i++) {
		      table.getColumn (i).pack ();
		    }     
		    
		    table.setSize(table.computeSize(SWT.DEFAULT, 200));
		    shell.pack();
		    shell.open();
		    while (!shell.isDisposed()) {
		      if (!display.readAndDispatch())
		        display.sleep();
		    }
		    display.dispose();
	}

}
