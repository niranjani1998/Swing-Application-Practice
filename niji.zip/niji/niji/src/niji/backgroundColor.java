package niji;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Shell;

public class backgroundColor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        final Display display=new Display();
        final Shell shell=new Shell(display);
        shell.setSize( 300, 300);
        shell.setLayout(new FillLayout(SWT.VERTICAL));
        Color color=display.getSystemColor(SWT.COLOR_CYAN);
        Group group=new Group(shell,SWT.NONE);
        group.setText( "Niji");
        group.setBackground( color);
       // group.setBackgroundMode(SWT.INHERIT_NONE);
        shell.pack();
        shell.open();
        while(!shell.isDisposed()) {
        	if(!display.readAndDispatch())
        		display.sleep();
        }
        display.dispose();
	}

}
