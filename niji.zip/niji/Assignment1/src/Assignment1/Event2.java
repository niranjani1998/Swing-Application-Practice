package Assignment1;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;

public class Event2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Display display = new Display();
		    Shell shell = new Shell(display);
		    shell.setText("Left click your mouse");
		    shell.setSize(200, 100);
		    shell.open();

		    shell.addListener(SWT.MouseDown, new SimpleListener("Shell mouse down listener"));

		    display.addFilter(SWT.MouseDown, new SimpleListener("Display mouse down Listener"));

		    display.addFilter(SWT.MouseUp, new SimpleListener("Display mouse up Listener"));

		    shell.open();
		    while (!shell.isDisposed()) { // Event loop.
		      if (!display.readAndDispatch())
		        display.sleep();
		    }
		    display.dispose();
	}

}
class SimpleListener implements Listener {
	  String name;

	  public SimpleListener(String name) {
	    this.name = name;
	  }

	  public void handleEvent(Event e) {
	    System.out.println("Event: [" + e.toString() + "] from " + name
	        + ". \tCurrent Time (in ms):  " + System.currentTimeMillis());
	  }
	}
