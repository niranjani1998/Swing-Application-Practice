package niji;



import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class backgroundimage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Display display=new Display();
        Shell shell=new Shell(display);
        //shell.setLayout(new FillLayout(SWT.VERTICAL));
       // shell.setSize(300, 300);
        shell.setFullScreen(true);
        //shell=new Shell(SWT.DIALOG_TRIM);
        shell=new Shell(SWT.SHELL_TRIM);
        Image image1=new Image(display,"C:\\Users\\Public\\Pictures\\Sample Pictures\\Desert.jpg");
        shell.setBackgroundImage(image1);
        //shell.setBackgroundMode(SWT.INHERIT_FORCE);
        
        
        
        shell.open();
        while(!shell.isDisposed()) {
        	if(!display.readAndDispatch())
        		display.sleep();
        }
        display.dispose();
	}

}
