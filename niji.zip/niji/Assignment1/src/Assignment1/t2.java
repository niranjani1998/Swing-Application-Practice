package Assignment1;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;

public class t2 {
    
    private Shell shell;
    
    public t2(Display display) {

        initUI(display);
    }

    private void initUI(Display display) {
        
        shell = new Shell(display, SWT.SHELL_TRIM | SWT.CENTER);
        
        RowLayout layout = new RowLayout();
        layout.marginTop = 50;
        layout.marginBottom = 150;
        layout.marginLeft = 50;
        layout.marginRight = 150;
        shell.setLayout(layout);
        
        Button msgBtn = new Button(shell, SWT.PUSH);
        msgBtn.setText("Show message");
        msgBtn.addListener(SWT.Selection, event -> doShowMessageBox());
        
        shell.setText("Message box");
        shell.pack();
        shell.open();

        while (!shell.isDisposed()) {
          if (!display.readAndDispatch()) {
            display.sleep();
          }
        }      
    }
    
    private void doShowMessageBox() {
        
        int style = SWT.ICON_INFORMATION | SWT.OK;

        MessageBox dia = new MessageBox(shell, style);
        dia.setText("Information");
        dia.setMessage("Download completed."); 
        dia.open();
    } 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Display display = new Display();
        t2 ex = new t2(display);
        display.dispose();
	}

}
