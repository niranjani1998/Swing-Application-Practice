package Task1;

public class concentrate {
	 static int sum(int x, int y) {
	      return x + y;
	   }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int p = sum(68, 28);
	      System.out.println("Sum: " + p);
	}

}
