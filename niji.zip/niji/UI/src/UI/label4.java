package UI;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

public class label4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final Display display = new Display();
	    final Shell shell = new Shell(display, SWT.SHELL_TRIM);
	    shell.setLayout(new RowLayout());

	    Label label = new Label(shell, SWT.BORDER );
	    label.setText("text on the label");

	    label.setImage(new Image(display,"C:\\Users\\user\\Pictures\\sangamam\\New folder\\FB_IMG_1577943518195.jpg"));
	    shell.open();
	    
	    while (!shell.isDisposed()) {
	      if (!display.readAndDispatch()) {
	        
	        display.sleep();
	      }
	    }
	    display.dispose();
	  }
	}


