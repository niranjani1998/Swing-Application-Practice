package Task1;

public class static1 {
	private static String note = "Bank";
	public static class SBISavings
	{
	public void displayOutput()
	{
	System.out.println(" SBISaving is: " + note);
	}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SBISavings bs = new static1.SBISavings();
		//calling the method
		bs.displayOutput();
	}

}
