package Controlstatements;

public class Public {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Person myObj = new Person(); 
		    System.out.println("Name: " + myObj.fname() );
		    System.out.println("Email: " + myObj.email());
		    //System.out.println("Age: " + myObj.age);
	}

}
