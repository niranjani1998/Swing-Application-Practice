package Task1;
 abstract class absclass {
	

	protected abstract void sound();
}
