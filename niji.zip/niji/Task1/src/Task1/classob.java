package Task1;

import java.util.Scanner;

public class classob {
	 int sum(int a, int b) {
	        return (a + b);
	    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int a, b, s;

	        Scanner sc = new Scanner(System.in);
	        System.out.print("Enter Two Numbers :");
	        a = sc.nextInt();
	        b = sc.nextInt();

	        classob dd = new classob();
	        s = dd.sum(a, b);

	        System.out.println("\nThe Sum is :" + s);
	}

}
