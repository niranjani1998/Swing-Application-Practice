package Task2;

import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.widgets.ColorDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class Color {
	private static void addWidgetsToShell(Display display, Shell shell) {
		  shell.open();
		  ColorDialog colorDialog1 = new ColorDialog(shell);
		  colorDialog1.setText("ColorDialog Demo");
		  colorDialog1.setRGB(new RGB(255, 100, 130));
		  RGB selectedColor = colorDialog1.open();

		  System.out.println("Red : " + selectedColor.red);
		  System.out.println("Green : " + selectedColor.green);
		  System.out.println("Blue : " + selectedColor.blue);
		 }


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Display display = new Display();

		 
		  Shell shell = new Shell(display);
		  shell.setSize(500, 500);
		  addWidgetsToShell(display, shell);

		

		  while (!shell.isDisposed()) {
		   if (!display.readAndDispatch()) {
		    display.sleep();
		   }
		  }

		  
		  display.dispose();
	}

}
