package UI;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

public class label1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Display display=new Display();
       Shell shell=new Shell(display);
       shell.setLayout( new GridLayout());
       new Label(shell,SWT.NONE).setText("Welcome to Thinkinnov");;
       shell.open();
       while(!shell.isDisposed()) {
    	   if(!display.readAndDispatch())
    		   display.sleep();
       }
       display.dispose();
	}

}
