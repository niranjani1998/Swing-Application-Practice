package Task1;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Link;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;

public class t1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  Display display = new Display();
		    Shell shell = new Shell(display);
		    Link link = new Link(shell, SWT.BORDER);
		    link.setText("This a very simple <A href=\"https://web.whatsapp.com/\\\">link</A> widget.");
		    link.setSize(300, 300);
		    
		    link.addListener (SWT.Selection, new Listener () {
		        public void handleEvent(Event event) {
		          System.out.println("Selection: " + event.text);
		        }
		      });
		    shell.pack ();
		    shell.open();
		    while (!shell.isDisposed()) {
		      if (!display.readAndDispatch())
		        display.sleep();
		    }
		    display.dispose();
	}

}
