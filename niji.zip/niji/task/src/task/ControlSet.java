package task;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class ControlSet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Display display = new Display();
	    final Shell shell = new Shell(display);
	   // shell.setLayout(new FillLayout());
	    shell.setLayout(new RowLayout());
	    
	    for (int i = 0; i < 20; i++) {
	      Button button = new Button(shell, SWT.PUSH);
	      button.setText("Tattu" + i);
	    }
	    for(int j=1 ;j<10;j++) {
	    	
	      Button button1 = new Button(shell, SWT.TOGGLE);
	      button1.setText("Niji" + j);
	    }
	     

	    
	   /* Control[] children = shell.getChildren();
	    for (int i = 0; i < children.length; i++) {
	      Control child = children[i];
	      System.out.println(child);
	    }*/

	    shell.pack();
	    shell.open();
	    while (!shell.isDisposed()) {
	      if (!display.readAndDispatch())
	        display.sleep();
	    }
	    display.dispose();
	}

}
