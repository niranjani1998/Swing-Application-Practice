package Java;
interface Name{
	public void name1();
	public void numb();
}
class Non1 implements Name{
	public void name1() {
		String st="Niji";
		System.out.println(st);
	}
	public void numb() {
		 int num[]= {'1','2','3'};
	       
	       for(int i=1;i<=num.length;i++) {
	    	   System.out.println(i);
	       }
		
	}
	
}

public class Non {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       //String st="Niji";
      Non1 nd=new Non1();
      nd.name1();
      nd.numb();
	}

}
