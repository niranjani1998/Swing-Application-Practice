package Controlstatements;

public class P1 extends Protected {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
           P1 my=new P1();
           my.display();
	}

}
