package task;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class Pattern {
         
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=5;
		Display display=new Display();
		Shell shell=new Shell(display);
		shell.setLayout(new FillLayout());
		for(int i=1;i<=n;i++) {
			for(int j=1;j<=i;j++) {
				Button button=new Button(shell,SWT.TOGGLE);
				button.setText("*" + i);
			}
		}
		shell.pack();
        shell.open();
        while(!shell.isDisposed()) {
        	if(!display.readAndDispatch())
        		display.sleep();
        }
        display.dispose();
	}

}
