package Controlstatements;

public class Person {
	     private String name="niji";
	     private String company="Thinkinnov";
         public String fname() {
        	 
        	 return name;
         }
         public String email() {
        	 return company;
        	 
         }
 public static void main(String[] args) {
	 Person my=new Person();
	 System.out.println("Name"+my.fname());
	 System.out.println("Name"+my.email());
 }
}
