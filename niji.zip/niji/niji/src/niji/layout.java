package niji;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class layout {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Display display = new Display();
	    Shell shell = new Shell(display);
	    shell.setLayout(new FormLayout());
	    Button button = new Button(shell, SWT.PUSH);
        Button button1=new Button(shell,SWT.CALENDAR_WEEKNUMBERS);
        Button button2=new Button(shell,SWT.ALPHA);
        button.setBounds(20, 20, 70, 70);
        button1.setBounds(20, 20, 70, 70);
        button2.setBounds(20, 20, 70, 70);
	    shell.setSize(400, 400);
	    shell.open();

	    System.out.println("------------------------------");
	    System.out.println("getBounds: " + button.getBounds());
	    System.out.println("getLocation: " + button.getLocation());
	    System.out.println("getSize: " + button.getSize());

	    while (!shell.isDisposed()) {
	      if (!display.readAndDispatch()) {
	        display.sleep();
	      }
	    }
	}

}
