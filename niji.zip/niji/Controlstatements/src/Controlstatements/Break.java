package Controlstatements;

public class Break {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     int i;
     for(i=1;i<=10;i++) {
    	 if(i==5)
    		break;
    	 System.out.println(i);
     }
	}

}
