package Task2;

import java.util.Objects;

import org.eclipse.swt.SWT;
import org.eclipse.swt.printing.PrintDialog;
import org.eclipse.swt.printing.PrinterData;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class Print {
	 private static void addWidgetsToShell(Display display, Shell shell) {
		  PrintDialog printDialog = new PrintDialog(shell, SWT.NONE);
		  printDialog.setText("PrintDialogDemo");
		  printDialog.setScope(PrinterData.PAGE_RANGE);
		  printDialog.setStartPage(2);
		  printDialog.setEndPage(5);
		  printDialog.setPrintToFile(true);
		  PrinterData printerData = printDialog.open();

		  if (!Objects.isNull(printerData)) {
		   switch (printerData.scope) {
		   case PrinterData.ALL_PAGES:
		    System.out.println("Printing all pages.");
		    break;
		   case PrinterData.SELECTION:
		    System.out.println("Printing selected page.");
		    break;
		   case PrinterData.PAGE_RANGE:
		    System.out.print("Printing page range. ");
		    System.out.print("From:" + printerData.startPage);
		    System.out.println(" to:" + printerData.endPage);
		    break;
		   }
		   if (printerData.printToFile)
		    System.out.println("Printing to file.");
		   else
		    System.out.println("Not printing to file.");
		   if (printerData.collate)
		    System.out.println("Collating.");
		   else
		    System.out.println("Not collating.");
		   System.out.println("Number of copies:" + printerData.copyCount);
		   System.out.println("Printer Name:" + printerData.name);
		  }
		  shell.dispose();
		 }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Display display = new Display();

		 
		  Shell shell = new Shell(display);
		  shell.setSize(500, 500);
		  addWidgetsToShell(display, shell);

		

		  while (!shell.isDisposed()) {
		   if (!display.readAndDispatch()) {
		    display.sleep();
		   }
		  }

		  
		  display.dispose();
	}

}
