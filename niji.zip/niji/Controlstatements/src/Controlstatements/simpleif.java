package Controlstatements;

public class simpleif {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          int a=5;
          if(a==5) {
        	  System.out.println("It is  in equal instance");
          }
	}

}
