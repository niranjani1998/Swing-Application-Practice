package Java;

public class Assignment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int a=5;
        System.out.println(a+=2);
        System.out.println(a-=2);
        System.out.println(a*=2);
        System.out.println(a/=2);
	}

}
